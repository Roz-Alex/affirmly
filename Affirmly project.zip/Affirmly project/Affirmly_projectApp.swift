//
//  Affirmly_projectApp.swift
//  Affirmly project
//
//  Created by krispi on 14/05/2025.
//

import SwiftUI

@main
struct Affirmly_projectApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
