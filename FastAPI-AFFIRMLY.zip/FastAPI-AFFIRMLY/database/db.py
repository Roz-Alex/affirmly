from databases import Database
import sqlalchemy
from sqlalchemy import MetaData

# Строка подключения с SSL
DATABASE_URL = "postgresql+asyncpg://entityfrm:pP3VJsoAcX2q@ep-mute-sun-a2woi1rv-pooler.eu-central-1.aws.neon.tech/mobile_dev?sslmode=require"

# Настроим базу данных
database = Database(DATABASE_URL)
metadata = MetaData()

# Создаём Engine для SQLAlchemy
engine = sqlalchemy.create_engine(DATABASE_URL, pool_size=3, max_overflow=0)
