from fastapi import FastAPI
from database import db  # Импортируем подключение из db.py

app = FastAPI()

# Подключение к базе данных при старте
@app.on_event("startup")
async def startup():
    await db.connect()

# Отключение при завершении работы
@app.on_event("shutdown")
async def shutdown():
    await db.disconnect()


